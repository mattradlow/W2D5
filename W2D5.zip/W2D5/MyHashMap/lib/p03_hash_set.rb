class HashSet
  attr_reader :count

  def initialize(num_buckets = 8)
    @store = Array.new(num_buckets) { Array.new }
    @count = 0
    @num_buckets = num_buckets 
  end

  def insert(key)
    if !self.include?(key)
      if @count + 1 > num_buckets
        resize!
      end
      self[key] << key
      @count += 1
    end
  end

  def include?(key)
    self[key].include?(key)
  end

  def remove(key)
    if self.include?(key)
      self[key].delete(key)
      @count -=1
    end
  end

  private

  def [](num)
    # optional but useful; return the bucket corresponding to `num`
    num_idx = num.hash % num_buckets 
    @store[num_idx] 
  end

  def num_buckets
    @store.length
  end

  def resize!
    arr = []
    @store.each do |bucket|
      arr.push(bucket.shift(bucket.length))
    end 
    
    @num_buckets *= 2
    (@num_buckets / 2).times { @store << [] } 
    
    arr.each do |ele| 
      self[ele] << ele 
    end 

  end
end
